# Installation and setup

Create a `.env` file in the ROOT folder and copy past the content of the `.env.sample` file in it.

Run the following commands to start the server

```bash
npm install
npm run dev

# Make sure to keep the freeapi server running
```
